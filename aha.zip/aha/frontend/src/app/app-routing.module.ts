// frontend/src/app/app-routing.module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { DiscussComponent } from './components/discuss/discuss.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/discuss', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { 
    path: 'discuss', 
    component: DiscussComponent, 
    canActivate: [AuthGuard] // Contoh guard untuk memastikan hanya user ter-autentikasi yang bisa akses
  },
  { path: '**', redirectTo: '/login' } // Redirect ke login untuk route tidak dikenal
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }