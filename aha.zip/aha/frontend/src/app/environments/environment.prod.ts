export const environment = {
    production: true,
    apiUrl: '/api' // untuk production
  };