// frontend/src/app/components/discuss/discuss.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommentService, Comment } from '../../services/comment.service';
import { AuthService } from '../../services/auth.services';

@Component({
  selector: 'app-discuss',
  templateUrl: './discuss.component.html',
  styleUrls: ['./discuss.component.css']
})
export class DiscussComponent implements OnInit {
  commentForm: FormGroup;
  comments: Comment[] = [];
  replyForms: { [key: string]: FormGroup } = {};

  constructor(
    private fb: FormBuilder,
    private commentService: CommentService,
    private authService: AuthService
  ) {
    this.commentForm = this.fb.group({
      content: ['', [Validators.required, Validators.minLength(3)]]
    });
  }

  ngOnInit() {
    this.loadComments();
  }

  loadComments() {
    this.commentService.getAllComments().subscribe(
      comments => {
        this.comments = comments;
        // Initialize reply forms for each comment
        comments.forEach(comment => {
          this.replyForms[comment._id || ''] = this.fb.group({
            content: ['', [Validators.required, Validators.minLength(3)]]
          });
        });
      },
      error => {
        console.error('Error loading comments', error);
      }
    );
  }

  onSubmitComment() {
    if (this.commentForm.valid) {
      this.commentService.createComment(this.commentForm.value.content)
        .subscribe(
          newComment => {
            this.comments.unshift(newComment);
            this.commentForm.reset();
          },
          error => {
            console.error('Error creating comment', error);
          }
        );
    }
  }

  onSubmitReply(parentCommentId: string) {
    const replyForm = this.replyForms[parentCommentId];
    if (replyForm.valid) {
      this.commentService.addReply(parentCommentId, replyForm.value.content)
        .subscribe(
          newReply => {
            const parentComment = this.comments.find(c => c._id === parentCommentId);
            if (parentComment) {
              if (!parentComment.replies) {
                parentComment.replies = [];
              }
              parentComment.replies.push(newReply);
            }
            replyForm.reset();
          },
          error => {
            console.error('Error adding reply', error);
          }
        );
    }
  }

  getCurrentUser() {
    return this.authService.currentUserValue;
  }

  deleteComment(commentId: string) {
    this.commentService.deleteComment(commentId)
      .subscribe(
        () => {
          // Remove comment from list
          this.comments = this.comments.filter(c => c._id !== commentId);
        },
        error => {
          console.error('Error deleting comment', error);
        }
      );
  }
}