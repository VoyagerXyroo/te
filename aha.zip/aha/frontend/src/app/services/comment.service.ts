// frontend/src/app/services/comment.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.services';

export interface Comment {
  _id?: string;
  content: string;
  author: {
    username: string;
  };
  parentComment?: string | null;
  replies?: Comment[];
  createdAt?: Date;
}

@Injectable({
  providedIn: 'root'
})
export class CommentService {
  private apiUrl = 'http://localhost:5000/api/comments';

  constructor(
    private http: HttpClient, 
    private authService: AuthService
  ) {}

  // Get headers with auth token
  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    });
  }

  // Create a new top-level comment
  createComment(content: string): Observable<Comment> {
    return this.http.post<Comment>(this.apiUrl, 
      { content }, 
      { headers: this.getHeaders() }
    );
  }

  // Get all top-level comments
  getAllComments(): Observable<Comment[]> {
    return this.http.get<Comment[]>(this.apiUrl);
  }

  // Add a reply to a specific comment
  addReply(commentId: string, content: string): Observable<Comment> {
    return this.http.post<Comment>(
      `${this.apiUrl}/${commentId}/replies`, 
      { content }, 
      { headers: this.getHeaders() }
    );
  }

  // Get replies for a specific comment
  getReplies(commentId: string): Observable<Comment[]> {
    return this.http.get<Comment[]>(`${this.apiUrl}/${commentId}/replies`);
  }

  // Update a comment
  updateComment(commentId: string, content: string): Observable<Comment> {
    return this.http.put<Comment>(
      `${this.apiUrl}/${commentId}`, 
      { content }, 
      { headers: this.getHeaders() }
    );
  }

  // Delete a comment
  deleteComment(commentId: string): Observable<{message: string}> {
    return this.http.delete<{message: string}>(
      `${this.apiUrl}/${commentId}`, 
      { headers: this.getHeaders() }
    );
  }
}