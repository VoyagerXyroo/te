// backend/routes/commentRoutes.js
const express = require('express');
const router = express.Router();
const commentController = require('../controllers/commentController');
const authMiddleware = require('../middleware/authMiddleware');

// Create a new comment (requires authentication)
router.post('/', authMiddleware, commentController.createComment);

// Get all top-level comments
router.get('/', commentController.getAllComments);

// Get replies to a specific comment
router.get('/:commentId/replies', commentController.getReplies);

// Add a reply to a comment (requires authentication)
router.post('/:commentId/replies', authMiddleware, commentController.addReply);

// Update a comment (only by the author)
router.put('/:commentId', authMiddleware, commentController.updateComment);

// Delete a comment (only by the author)
router.delete('/:commentId', authMiddleware, commentController.deleteComment);

module.exports = router;