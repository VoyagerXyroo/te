// frontend/src/app/components/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.services';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  errorMessage: string = '';
  isLoading: boolean = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      username: ['', [
        Validators.required, 
        Validators.minLength(3),
        Validators.maxLength(20)
      ]],
      password: ['', [
        Validators.required,
        Validators.minLength(6)
      ]]
    });
  }

  ngOnInit(): void {
    // Redirect to discuss page if already logged in
    if (this.authService.isLoggedIn()) {
      this.router.navigate(['/discuss']);
    }
  }

  onSubmit() {
    if (this.loginForm.invalid) {
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const { username, password } = this.loginForm.value;

    this.authService.login({ username, password })
      .subscribe({
        next: (user) => {
          this.isLoading = false;
          // Redirect to discuss page after successful login
          this.router.navigate(['/discuss']);
        },
        error: (error) => {
          this.isLoading = false;
          // Handle login error
          this.errorMessage = error.error?.message || 'Login failed. Please try again.';
        }
      });
  }

  // Convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }
}