// frontend/src/app/services/auth.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from '../environments/environment';

export interface User {
  id: string;
  username: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export interface SignupCredentials extends LoginCredentials {
  email: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject: BehaviorSubject<User | null>;
  private apiUrl = 'http://localhost:5000/api/auth';

  constructor(private http: HttpClient) {
    const storedUser = localStorage.getItem('currentUser');
    this.currentUserSubject = new BehaviorSubject<User | null>(
      storedUser ? JSON.parse(storedUser) : null
    );
  }

  public get currentUserValue(): User | null {
    return this.currentUserSubject.value;
  }

  login(credentials: LoginCredentials): Observable<User> {
    return this.http.post<{token: string, user: User}>(`${this.apiUrl}/login`, credentials)
      .pipe(map(response => {
        // Login successful if there's a jwt token in the response
        if (response.token) {
          // Store user details and jwt token in local storage
          localStorage.setItem('currentUser', JSON.stringify(response.user));
          localStorage.setItem('token', response.token);
          
          // Set current user subject
          this.currentUserSubject.next(response.user);
          
          return response.user;
        }
        throw new Error('Login failed');
      }));
  }

  signup(credentials: SignupCredentials): Observable<User> {
    return this.http.post<{token: string, user: User}>(`${this.apiUrl}/signup`, credentials)
      .pipe(map(response => {
        if (response.token) {
          // Store user details and jwt token in local storage
          localStorage.setItem('currentUser', JSON.stringify(response.user));
          localStorage.setItem('token', response.token);
          
          // Set current user subject
          this.currentUserSubject.next(response.user);
          
          return response.user;
        }
        throw new Error('Signup failed');
      }));
  }

  logout() {
    // Remove user from local storage
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
    
    // Reset current user subject
    this.currentUserSubject.next(null);
  }

  // Method to get the current auth token
  getToken(): string | null {
    return localStorage.getItem('token');
  }

  // Check if user is logged in
  isLoggedIn(): boolean {
    return !!this.getToken();
  }
}